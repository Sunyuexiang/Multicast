from flask import Flask, render_template, request, jsonify, send_from_directory, url_for, flash
from werkzeug.utils import secure_filename
import networkx as nx
import matplotlib.pyplot as plt
import json
import os
import time
import pickle
from datetime import datetime
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['IMAGE_FOLDER'] = 'images/'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['IMAGE_FOLDER'], exist_ok=True)
group_counter = 1
group_files = {}  # Dictionary to store group name and file list
uploaded_files = []

def init_db():
    conn = sqlite3.connect('fileinfo.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            content TEXT NOT NULL,
            upload_time TIMESTAMP NOT NULL,
            update_time TIMESTAMP NOT NULL,
            delete_time TIMESTAMP,
            is_active INTEGER NOT NULL DEFAULT 1
        )
    ''')
    conn.commit()
    conn.close()


init_db()  # Ensure the database and table are created


@app.route('/')
def index():
    return render_template('Sign_in.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    if file and file.filename.endswith('.json'):
        filename = secure_filename(file.filename)
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(json_path)
        try:
            image_filename = create_topology(json_path)
            image_url = url_for('send_image', filename=image_filename,
                                _external=True)  # Generate the full URL for the image
            return jsonify({'message': 'File uploaded successfully', 'filename': image_url})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    return jsonify({'error': 'Invalid file type'})


def create_topology(json_path, highlight_data=None):
    graph_filename = 'base_graph.pkl'  # 基础图保存文件名
    timestamp = str(int(time.time()))  # 使用时间戳创建唯一的文件名
    output_filename = secure_filename(os.path.splitext(os.path.basename(json_path))[0] + f'_{timestamp}.png')
    output_path = os.path.join(app.config['IMAGE_FOLDER'], output_filename)
    if highlight_data is None:
        with open(json_path, 'r') as json_file:
            data = json.load(json_file)

        G = nx.Graph()
        for node, edges in data['topo'].items():
            for dest, weight in edges.items():
                G.add_edge(node, dest, weight=weight)

        with open(graph_filename, 'wb') as f:
            pickle.dump(G, f)

    else:
        with open(graph_filename, 'rb') as f:
            G = pickle.load(f)

        color_map = {group: color for group, color in zip(highlight_data.keys(), ['red', 'green', 'orange'])}
        for group, info in highlight_data.items():
            source, targets = info['source'], info['targets']
            for node in [source] + targets:
                G.nodes[node]['color'] = color_map[group]

    node_colors = [G.nodes[node].get('color', 'skyblue') for node in G.nodes()]

    output_filename = secure_filename(os.path.splitext(os.path.basename(json_path))[0] + '.png')
    output_path = os.path.join(app.config['IMAGE_FOLDER'], output_filename)

    plt.figure(figsize=(8, 6))
    pos = nx.spring_layout(G, seed=42)  # 42可以替换成其他整数
    nx.draw(G, pos, with_labels=True, node_size=600, node_color=node_colors, font_size=6)
    edge_labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
    plt.savefig(output_path)
    plt.close()

    return output_filename


@app.route('/images/<filename>')
def send_image(filename):
    return send_from_directory(app.config['IMAGE_FOLDER'], filename)


@app.route('/upload_json', methods=['POST'])
def upload_json():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    if file and file.filename.endswith('.json'):
        filename = secure_filename(file.filename)
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(json_path)
        uploaded_files.append(filename)  # 添加文件到列表
        return jsonify({'message': 'File uploaded successfully', 'filename': filename})
    return jsonify({'error': 'Invalid file type'})


@app.route('/delete_json/<filename>', methods=['DELETE'])
def delete_json(filename):
    if filename in uploaded_files:
        uploaded_files.remove(filename)  # 从列表中删除文件
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        os.remove(json_path)  # 删除文件
        return jsonify({'message': 'File deleted successfully'})
    else:
        return jsonify({'error': 'File not found'}), 404


@app.route('/Sign_in', methods=['POST', 'GET'])
def login_post():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'root' and password == '123':
            return render_template('index.html')  # 确保有 index.html 页面
        else:
            return render_template("Error.html")
    return render_template('Sign_in.html')


@app.route('/upload_multicast', methods=['POST'])
def upload_multicast_files():
    global group_counter
    files = request.files.getlist('files[]')
    highlight_data = {}
    group_name = f"Group{group_counter}"
    group_counter += 1
    saved_files = []

    multicast_upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], group_name)
    os.makedirs(multicast_upload_dir, exist_ok=True)

    # 连接数据库
    conn = sqlite3.connect('fileinfo.db')
    c = conn.cursor()

    for file in files:
        if file and file.filename.endswith('.json'):
            filename = secure_filename(file.filename)
            json_path = os.path.join(multicast_upload_dir, filename)
            file.save(json_path)
            saved_files.append(filename)

            with open(json_path, 'r') as f:
                content = f.read()  # 读取文件内容以保存到数据库
                data = json.loads(content)
                for group, info in data.items():
                    highlight_data[group] = {'source': info['source'], 'targets': info['targets']}

            # 保存文件信息到数据库
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            c.execute('INSERT INTO files (filename, content, upload_time, update_time) VALUES (?, ?, ?, ?)',
                      (filename, content, now, now))
            conn.commit()

    # 更新 group_files 字典，这将不影响其它功能
    group_files[group_name] = saved_files

    # 继续处理生成拓扑图的逻辑
    image_filename = create_topology(json_path, highlight_data)

    conn.close()  # 确保在所有操作完成后关闭数据库连接
    return jsonify({
        'message': 'Files uploaded successfully',
        'group_name': group_name,
        'files': saved_files,
        'filename': url_for('send_image', filename=image_filename)
    })


@app.route('/delete_group/<group_name>', methods=['DELETE'])
def delete_group(group_name):
    if group_name in group_files:
        for filename in group_files[group_name]:
            json_path = os.path.join(app.config['UPLOAD_FOLDER'], group_name, filename)
            if os.path.exists(json_path):
                os.remove(json_path)  # 删除文件

                # 更新数据库记录
                conn = sqlite3.connect('fileinfo.db')
                c = conn.cursor()
                now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                c.execute('UPDATE files SET is_active = 0, delete_time = ? WHERE filename = ?',
                          (now, filename))
                conn.commit()
                conn.close()

        del group_files[group_name]
        return jsonify({'message': 'Group deleted successfully'})
    else:
        return jsonify({'error': 'Group not found'}), 404



@app.route('/get_file_content/<filename>')
def get_file_content(filename):
    for group_name, files in group_files.items():
        if filename in files:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], group_name, filename)
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as file:
                        content = file.read()
                    return jsonify({'content': content})
                except IOError as e:
                    app.logger.error(f"Error reading file: {e}")
                    return jsonify({'error': 'Error reading file'}), 500
            else:
                app.logger.error(f"File not found: {file_path}")
    app.logger.error(f"File not listed in uploaded files: {filename}")
    return jsonify({'error': 'File not found'}), 404




if __name__ == '__main__':
    app.run(debug=True)
