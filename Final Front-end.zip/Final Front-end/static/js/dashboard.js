// Function to process the JSON data and return Vis.js-compatible datasets
function processJson(jsonData) {
  const nodesArray = [];
  const edgesArray = [];

  // Process nodes
  for (const [dpid, switchname] of Object.entries(jsonData.dpid_to_switchname)) {
    nodesArray.push({ id: dpid, label: switchname });
  }

  // Process edges
  for (const [source, targets] of Object.entries(jsonData.topo)) {
    const sourceId = getKeyByValue(jsonData.dpid_to_switchname, source);
    for (const [target, port] of Object.entries(targets)) {
      const targetId = getKeyByValue(jsonData.dpid_to_switchname, target);
      edgesArray.push({ from: sourceId, to: targetId, label: String(port) });
    }
  }

  return { nodes: nodesArray, edges: edgesArray };
}

// Helper function to get the key by value from an object
function getKeyByValue(object, value) {
  return Object.keys(object).find(key => object[key] === value);
}

document.getElementById('topoButton').addEventListener('click', function() {
  // Assuming you have the JSON data locally available as `netconf.json.json`
  // Replace the fetch with a real URI if you need to load the JSON from a server
  fetch('path/to/your/netconf.json')
      .then(response => response.json())
      .then(jsonData => {
        const { nodes, edges } = processJson(jsonData);

        // Create a network
        const container = document.getElementById('mynetwork');
        const data = {
          nodes: new vis.DataSet(nodes),
          edges: new vis.DataSet(edges)
        };
        const options = {};
        const network = new vis.Network(container, data, options);
      })
      .catch(error => console.error('Error loading the JSON data:', error));
});
