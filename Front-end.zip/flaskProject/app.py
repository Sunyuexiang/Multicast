from flask import Flask, render_template, request, jsonify, send_from_directory, url_for, flash
from werkzeug.utils import secure_filename
from graphviz import Digraph
from markupsafe import escape
import json
import os


app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['IMAGE_FOLDER'] = 'images/'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['IMAGE_FOLDER'], exist_ok=True)
group_counter = 1
group_files = {}  # Dictionary to store group name and file list


@app.route('/')
def index():
    return render_template('Sign_in.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    if file and file.filename.endswith('.json'):
        filename = secure_filename(file.filename)
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(json_path)
        try:
            image_filename = create_topology(json_path)
            image_url = url_for('send_image', filename=image_filename,
                                _external=True)  # Generate the full URL for the image
            return jsonify({'message': 'File uploaded successfully', 'filename': image_url})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    return jsonify({'error': 'Invalid file type'})


def create_topology(json_path):
    with open(json_path, 'r') as json_file:
        data = json.load(json_file)

    dot = Digraph(comment='Network Topology')
    for node, edges in data['topo'].items():
        dot.node(node)
        for dest, weight in edges.items():
            dot.edge(node, dest, label=str(weight))

    output_filename = secure_filename(json_path)
    output_path = os.path.join(app.config['IMAGE_FOLDER'], output_filename)
    dot.render(output_path, format='png', cleanup=True)
    return output_filename


@app.route('/images/<filename>')
def send_image(filename):
    return send_from_directory(app.config['IMAGE_FOLDER'], filename)

uploaded_files = []

@app.route('/upload_json', methods=['POST'])
def upload_json():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    if file and file.filename.endswith('.json'):
        filename = secure_filename(file.filename)
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(json_path)
        uploaded_files.append(filename)  # 添加文件到列表
        return jsonify({'message': 'File uploaded successfully', 'filename': filename})
    return jsonify({'error': 'Invalid file type'})

@app.route('/delete_json/<filename>', methods=['DELETE'])
def delete_json(filename):
    if filename in uploaded_files:
        uploaded_files.remove(filename)  # 从列表中删除文件
        json_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        os.remove(json_path)  # 删除文件
        return jsonify({'message': 'File deleted successfully'})
    else:
        return jsonify({'error': 'File not found'}), 404

@app.route('/Sign_in', methods=['POST', 'GET'])
def login_post():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'root' and password == '123':
            return render_template('index.html')  # 确保有 index.html 页面
        else:
            return render_template("Error.html")
    return render_template('Sign_in.html')

@app.route('/upload_multicast', methods=['POST'])
def upload_multicast_files():
    global group_counter
    files = request.files.getlist('files[]')  # 获取文件列表
    group_name = f"Group{group_counter}"
    group_counter += 1
    saved_files = []

    # 确保多播上传目录存在
    multicast_upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], group_name)
    os.makedirs(multicast_upload_dir, exist_ok=True)

    for file in files:
        if file and file.filename.endswith('.json'):
            filename = secure_filename(file.filename)
            file.save(os.path.join(multicast_upload_dir, filename))  # 保存文件到对应的多播上传目录
            saved_files.append(filename)

    group_files[group_name] = saved_files  # 将文件名添加到group_files字典的对应组中
    return jsonify({'message': 'Files uploaded successfully', 'group_name': group_name, 'files': saved_files})

@app.route('/delete_group/<group_name>', methods=['DELETE'])
def delete_group(group_name):
    if group_name in group_files:
        for filename in group_files[group_name]:
            json_path = os.path.join(app.config['UPLOAD_FOLDER'], group_name, filename)
            if os.path.exists(json_path):
                os.remove(json_path)  # 确保文件被删除
        del group_files[group_name]  # 从记录中删除组信息
        return jsonify({'message': 'Group deleted successfully'})
    else:
        return jsonify({'error': 'Group not found'}), 404

@app.route('/get_file_content/<filename>')
def get_file_content(filename):
    # 遍历所有组查找文件
    for group_name, files in group_files.items():
        if filename in files:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], group_name, filename)
            if os.path.exists(file_path):  # 确保文件确实存在
                try:
                    with open(file_path, 'r') as file:
                        content = file.read()
                    return jsonify({'content': content})
                except IOError as e:
                    app.logger.error(f"Error reading file: {e}")
                    return jsonify({'error': 'Error reading file'}), 500
            else:
                app.logger.error(f"File not found: {file_path}")
                continue  # 继续检查其他组

    # 如果文件没有在任何组中找到
    app.logger.error(f"File not listed in uploaded files: {filename}")
    return jsonify({'error': 'File not found'}), 404


if __name__ == '__main__':
    app.run(debug=True)
